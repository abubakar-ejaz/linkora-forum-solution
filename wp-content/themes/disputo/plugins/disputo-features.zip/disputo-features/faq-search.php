<div id="disputo-live-search-container">
    <input type="text" class="disputo-live-search-box" placeholder="<?php esc_attr_e('Enter a keyword...', 'disputo'); ?>" />
    <div class="disputo-live-search-icon"></div>
</div>
<div id="disputo-no-results-message" class="alert alert-danger">
    <?php esc_attr_e('No results found.', 'disputo'); ?>
</div>